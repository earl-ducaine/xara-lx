#!/bin/sh
automake
autoconf
