== Todo list for fp-perf-exp ==

√ Fill in README.md
√ Add other source code files to src/meson.build
√ Flesh out main.c
√ Flesh out stubbed operation routines

For a non-SSE version of fixedptc.h, see
   https://github.com/andrewray/mirage-kfreebsd/blob/master/fixpt/fixedptc.h
